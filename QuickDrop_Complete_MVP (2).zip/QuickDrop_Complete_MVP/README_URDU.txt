QUICKDROP MULTAN — COMPLETE MVP PACKAGE

Is package mein customer signup/login, parcel booking, public tracking code,
Super Admin dashboard, order status updates aur rider account creation hai.
Admin role public signup se kabhi create nahi hota. Admin sirf server command
se banega aur database index doosra Admin banne se rokta hai.

IMPORTANT: Main aapke naam par hosting/database account create ya deploy nahi
kar sakta. Is liye yeh complete deploy-ready source hai, live website abhi nahi.
Live karne ke liye aapko apna database aur hosting account connect karna hoga.

LOCAL RUN (computer par):
1. Node.js 20 ya newer install karein.
2. Is folder mein terminal open karein.
3. .env.example ki copy bana kar .env naam dein.
4. PostgreSQL database banayein aur DATABASE_URL paste karein.
5. JWT_SECRET ko 32+ characters ke random secret se replace karein.
6. ADMIN_NAME, ADMIN_EMAIL, ADMIN_PHONE, ADMIN_PASSWORD apni details se fill karein.
   Admin password kam az kam 12 characters ka ho. Password kisi ko na bhejein.
7. Commands chalayein:
   npm install
   npx prisma generate
   npx prisma db push
   npx prisma db execute --file prisma/migrations/202611090001_single_admin/migration.sql
   npm run admin:create
   npm start
8. Browser mein http://localhost:4000 kholein.

HOSTING:
- Node hosting (misal: Render Web Service) aur managed PostgreSQL (misal: Neon)
  par deploy karna hoga.
- Hosting ke Environment Variables mein .env wali values add karein.
- Build command (render.yaml mein pehle se diya hai): npm install && npx prisma generate && npx prisma db push
- Start command: npm start
- Deploy hone ke baad Render Shell mein aik martaba yeh command chalayein:
  npx prisma db execute --file prisma/migrations/202611090001_single_admin/migration.sql
  npm run admin:create
- ADMIN_NAME, ADMIN_EMAIL, ADMIN_PHONE, ADMIN_PASSWORD environment variables mein pehle set hon.
- DATABASE_URL aur JWT_SECRET ko kabhi frontend mein na rakhein.

LIMITS / HONEST STATUS:
Yeh operational MVP source hai, lekin live rider GPS, SMS OTP, payments,
WhatsApp notifications, maps routing, Android APK aur Play Store publishing
abhi included nahi. Real customer deliveries shuru karne se pehle service,
pricing, privacy policy, rider vetting aur emergency/support process verify karein.
