-- A database-level guard: only one ADMIN account can exist at a time.
CREATE UNIQUE INDEX IF NOT EXISTS "User_single_admin_only"
ON "User" ("role") WHERE "role" = 'ADMIN';
