import "dotenv/config";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "./db.js";

const input = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.email().transform(v => v.toLowerCase()),
  phone: z.string().regex(/^03\d{9}$/),
  password: z.string().min(12).max(72)
}).parse({
  name: process.env.ADMIN_NAME,
  email: process.env.ADMIN_EMAIL,
  phone: process.env.ADMIN_PHONE,
  password: process.env.ADMIN_PASSWORD
});

try {
  const currentAdmin = await prisma.user.findFirst({ where: { role: "ADMIN" } });
  if (currentAdmin && currentAdmin.email !== input.email) {
    throw new Error(`A Super Admin already exists (${currentAdmin.email}). Only one is allowed.`);
  }
  const passwordHash = await bcrypt.hash(input.password, 12);
  const admin = await prisma.user.upsert({
    where: { email: input.email },
    update: { name: input.name, phone: input.phone, passwordHash, role: "ADMIN", active: true },
    create: { ...input, passwordHash, role: "ADMIN" }
  });
  console.log(`Super Admin ready: ${admin.email}`);
} finally {
  await prisma.$disconnect();
}
