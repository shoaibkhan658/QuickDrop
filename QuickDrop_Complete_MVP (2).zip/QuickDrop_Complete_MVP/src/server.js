import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { prisma } from "./db.js";
import { requireAuth, requireRole } from "./middleware/auth.js";

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
const origins = (process.env.CORS_ORIGIN || "").split(",").map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: origins.length ? origins : false }));
app.use(express.json({ limit: "20kb" }));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const tokenFor = user => jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "12h" });
const publicUser = ({ id, name, email, phone, role }) => ({ id, name, email, phone, role });
const phoneSchema = z.string().regex(/^03\d{9}$/, "Use Pakistani mobile format 03XXXXXXXXX");
const registerSchema = z.object({ name: z.string().trim().min(2).max(80), email: z.email().transform(v => v.toLowerCase()), phone: phoneSchema, password: z.string().min(10).max(72) });
const loginSchema = z.object({ email: z.email().transform(v => v.toLowerCase()), password: z.string().min(1).max(72) });
const orderSchema = z.object({ pickupAddress: z.string().trim().min(5).max(300), dropoffAddress: z.string().trim().min(5).max(300), parcelType: z.string().trim().min(2).max(60), notes: z.string().max(500).optional() });

app.get("/api/health", (req, res) => res.json({ ok: true, service: "QuickDrop API" }));
app.post("/api/auth/register", asyncRoute(async (req, res) => {
  const input = registerSchema.parse(req.body);
  const passwordHash = await bcrypt.hash(input.password, 12);
  const user = await prisma.user.create({ data: { ...input, passwordHash, role: "CUSTOMER" } });
  res.status(201).json({ token: tokenFor(user), user: publicUser(user) });
}));
app.post("/api/auth/login", asyncRoute(async (req, res) => {
  const input = loginSchema.parse(req.body);
  const user = await prisma.user.findUnique({ where: { email: input.email } });
  if (!user || !user.active || !(await bcrypt.compare(input.password, user.passwordHash))) return res.status(401).json({ error: "Email ya password ghalat hai." });
  res.json({ token: tokenFor(user), user: publicUser(user) });
}));
app.get("/api/me", requireAuth, (req, res) => res.json({ user: req.user }));
app.post("/api/orders", requireAuth, requireRole("CUSTOMER"), asyncRoute(async (req, res) => {
  const input = orderSchema.parse(req.body);
  const order = await prisma.order.create({ data: { ...input, customerId: req.user.id, trackingCode: "QD-" + randomBytes(5).toString("hex").toUpperCase() }, select: { id: true, trackingCode: true, pickupAddress: true, dropoffAddress: true, parcelType: true, status: true, createdAt: true } });
  res.status(201).json({ order });
}));
app.get("/api/orders/mine", requireAuth, requireRole("CUSTOMER"), asyncRoute(async (req, res) => {
  const orders = await prisma.order.findMany({ where: { customerId: req.user.id }, orderBy: { createdAt: "desc" }, take: 100 });
  res.json({ orders });
}));
app.get("/api/orders/track/:code", asyncRoute(async (req, res) => {
  const code = req.params.code.toUpperCase();
  const order = await prisma.order.findUnique({ where: { trackingCode: code }, select: { trackingCode: true, status: true, pickupAddress: true, dropoffAddress: true, parcelType: true, createdAt: true, updatedAt: true } });
  if (!order) return res.status(404).json({ error: "Tracking code nahi mila." });
  res.json({ order });
}));

app.get("/api/admin/summary", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const [totalOrders, pendingOrders, activeRiders, totalCustomers] = await Promise.all([
    prisma.order.count(), prisma.order.count({ where: { status: "PENDING" } }), prisma.rider.count({ where: { active: true } }), prisma.user.count({ where: { role: "CUSTOMER", active: true } })
  ]);
  res.json({ totalOrders, pendingOrders, activeRiders, totalCustomers });
}));
app.get("/api/admin/orders", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const orders = await prisma.order.findMany({ include: { customer: { select: { name: true, phone: true } }, rider: { include: { user: { select: { name: true, phone: true } } } } }, orderBy: { createdAt: "desc" }, take: 250 });
  res.json({ orders });
}));
app.patch("/api/admin/orders/:id/status", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const { status } = z.object({ status: z.enum(["PENDING", "ASSIGNED", "PICKED_UP", "IN_TRANSIT", "DELIVERED", "CANCELLED"]) }).parse(req.body);
  const order = await prisma.order.update({ where: { id: req.params.id }, data: { status } });
  res.json({ order });
}));
app.post("/api/admin/orders/:id/assign", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const { riderId } = z.object({ riderId: z.string().min(1) }).parse(req.body);
  const rider = await prisma.rider.findFirst({ where: { id: riderId, active: true } });
  if (!rider) return res.status(404).json({ error: "Active rider nahi mila." });
  const order = await prisma.order.update({ where: { id: req.params.id }, data: { riderId, status: "ASSIGNED" } });
  res.json({ order });
}));
app.post("/api/admin/riders", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const input = z.object({ name: z.string().trim().min(2).max(80), email: z.email().transform(v => v.toLowerCase()), phone: phoneSchema, temporaryPassword: z.string().min(10).max(72), vehicle: z.string().max(80).optional() }).parse(req.body);
  const passwordHash = await bcrypt.hash(input.temporaryPassword, 12);
  const rider = await prisma.user.create({ data: { name: input.name, email: input.email, phone: input.phone, passwordHash, role: "RIDER", rider: { create: { vehicle: input.vehicle } } }, select: { id: true, name: true, email: true, phone: true, role: true, rider: true } });
  res.status(201).json({ rider });
}));
app.get("/api/admin/riders", requireAuth, requireRole("ADMIN"), asyncRoute(async (req, res) => {
  const riders = await prisma.rider.findMany({ where: { active: true }, include: { user: { select: { id: true, name: true, email: true, phone: true, active: true } } }, orderBy: { createdAt: "desc" } });
  res.json({ riders });
}));

const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, "../public")));
app.use((req, res, next) => { if (req.method !== "GET" || req.path.startsWith("/api/")) return next(); res.sendFile(path.join(__dirname, "../public/index.html")); });
app.use((err, req, res, next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: "Invalid form data", details: err.issues });
  if (err.code === "P2002") return res.status(409).json({ error: "Email ya phone pehle se registered hai." });
  if (err.code === "P2025") return res.status(404).json({ error: "Record nahi mila." });
  if (err.code === "P2004" || err.code === "P2010") return res.status(409).json({ error: "Database constraint: sirf aik Super Admin allowed hai." });
  console.error(err);
  res.status(500).json({ error: "Server error. Please try again." });
});
const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`QuickDrop running on port ${port}`));
